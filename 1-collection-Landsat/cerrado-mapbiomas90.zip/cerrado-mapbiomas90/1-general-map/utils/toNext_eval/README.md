avaliação da coleção 7.1
